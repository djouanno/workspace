package fr.esir.xml.question6;

public class Ville
{
    private String codePostal;
    private String nom;

    public Ville() {

    }

    public String getCodePostal() {
        return codePostal;
    }

    public void setCodePostal(final String codePostal) {
        this.codePostal = codePostal;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(final String nom) {
        this.nom = nom;
    }

}
